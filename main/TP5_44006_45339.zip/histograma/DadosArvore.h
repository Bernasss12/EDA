#pragma once
#include "Circulo.h"

class DadosArvore
{
private:
	Circulo* circulos;
	int ncirculos;
public:
	DadosArvore();
	~DadosArvore();
};

