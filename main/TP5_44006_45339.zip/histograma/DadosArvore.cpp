#include "DadosArvore.h"



DadosArvore::DadosArvore()
{
	ncirculos = 0;
	circulos = NULL;
}


DadosArvore::~DadosArvore()
{
}
